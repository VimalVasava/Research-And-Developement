import java.util.*;
import java.io.*;
import java.net.*;

class Q4_Server
{
	
	public static void main(String[] arg)
	{
		try
		{
			int sendData,receiveData,sum,num1,num2;
			String myStr;
			char cArray[]=null;
			int intArray[]=null;
			ServerSocket ss=new ServerSocket(5050);
			
			while(true)
			{
				System.out.println("Server Waiting for connection");
				Socket s=ss.accept();
				System.out.println("Connection establish");
				
				InputStream is=s.getInputStream();
				OutputStream os=s.getOutputStream();
				
				Scanner sc=new Scanner(is);
				PrintWriter pw = new PrintWriter(os,true);
				
				Scanner sendInput=new Scanner(System.in);
				myStr=sc.nextLine();
				
				int temp=Integer.parseInt(myStr);
				int temp1=temp;
				int ans=0;
				while(temp>0)
				{
					ans=ans+(temp % 10);
					temp= temp/10;
				}
				pw.println(ans);
			//pw.println("Original String is : "+temp1+"and Sum of degits : "+ans);
				
				
				
			
				
				
				
				
				
			}
		}catch(Exception e)
		{
			
		}
	}	
}			