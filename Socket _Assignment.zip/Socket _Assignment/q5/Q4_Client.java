
import java.util.*;
import java.io.*;
import java.net.*;
class Q4_Client
{
	
	public static void main(String[] arg)
	{
		String sendData,receiveData;
		try
		{
			Socket s=new Socket("localhost",5050);
			System.out.println("Request for Connection");
			InputStream is=s.getInputStream();
			OutputStream os=s.getOutputStream();
			
			Scanner sc=new Scanner(is);
			PrintWriter pw=new PrintWriter(os,true);
			Scanner sendInput=new Scanner(System.in);
			
			System.out.println("Enter the number");
			sendData=sendInput.nextLine();
			pw.println(sendData);
			
			System.out.println("Original String is : "+sendData+"and Sum is : "+sc.nextDouble());
			
		}catch(Exception e)
		{
			
		}
			
	}

}	