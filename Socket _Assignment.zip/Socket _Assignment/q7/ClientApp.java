
import java.io.*;
import java.util.*;
import java.net.*;
class ClientApp
{
	
	public static void main(String[] arg)throws Exception
	{
		Socket s=new Socket("127.0.0.1",5252);
		System.out.println("Request for connection");
		ClientSend clS=new ClientSend(s);
		ClientReceive clR=new ClientReceive(s);
		
		Thread t1=new Thread(clS);
		Thread t2=new Thread(clR);
		
		t1.start();
		t2.start();
	}
}
class ClientSend implements Runnable
{
	Socket s;
	public ClientSend(Socket s)
	{
		this.s=s;
	}
	public void run()
	{
		try
		{
			Scanner sc=new Scanner(System.in);
			PrintWriter pw=new PrintWriter(s.getOutputStream(),true);
			String str;
			while(true)
			{
				str=sc.nextLine();
				pw.println(s.getLocalSocketAddress());
				pw.println(str);
				if(str.equals("bye"))
				{
					System.exit(0);
					break;
				}
			}
		}
		catch(Exception e)
		{ }
		
	}
}
class ClientReceive implements Runnable
{
	Socket s;
	public ClientReceive(Socket s)
	{
		this.s=s;
	}
		public void run()
		{
			try
			{
				Scanner sc=new Scanner(s.getInputStream());
				String Line;
				while(true)
				{
					Line=sc.nextLine();
					System.out.println(Line);
				}
			}
			catch(Exception e)
			{
			
			}
		}
}

/************************************************Output  client : Vimal **************************************************

Z:\Assignment\q7>javac ClientApp.java

Z:\Assignment\q7>java ClientApp
Request for connection
hello Brothers
client 3 : hello i am Vimal
Ok I am Gautam
client 4 : hii I am John
client 3 : ok john welcome
client 4 : i am from japan

*********************************************************************************************************/

/************************************************Output  client : John ***********************************
Z:\Assignment\q7>java ClientApp
Request for connection
hii I am John
client 3 : ok john welcome
i am from japan
*********************************************************************************************************/

/************************************************Output  client : Gautam *********************************
Z:\Assignment\q7>java ClientApp
Request for connection
hello i am Vimal
client 2 : Ok I am Gautam
client 4 : hii I am John
ok john welcome
client 4 : i am from japan
*********************************************************************************************************/