/*=======================================================================================================
ROLL NO		:	44	

NAME		:	VIMALKUMAR V VASAVA

COURCE/SEM	:	MCA - IV

SUBJECT		: DISTRIBUTED APPLICATION DEVELOPMENT

ASSIGNMENT	: 1

			7.	write a chat server and client program. The chat server accepts connections from clients.
				Whenever one of the clients sends a chat message, it is displayed for all other clients to see. 
				Use a protocol with three commands : LOGIN name, CHAT message and LOGOUT.
		
========================================================================================================*/
import java.io.*;
import java.util.*;
import java.net.*;
class SeverApp
{
	public static void main(String[] srt)throws Exception
	{
		ServerSocket ss=new ServerSocket(5252);
		int count = 1;
		String Cl_name;
		while(true)
		{
			Socket s=ss.accept();
			
			Cl_name="client "+count;
			count++;
			
			ServerReceive.addClient(s);
			//System.out.println("connection establish : " + Cl_name);
			ServerReceive Sr=new ServerReceive(s,Cl_name);
			Thread t1=new Thread(Sr);
			t1.start();
			
		}
	}
}
class ServerReceive implements Runnable
{
	Socket s;
	String Cl_name;
	public ServerReceive(Socket s,String Cl_name)
	{
		this.s=s;
		this.Cl_name=Cl_name;
	}
	
	static ArrayList<Socket> arryL=new ArrayList<Socket>();
	static void addClient(Socket s)
	{
		arryL.add(s);
		System.out.println("Available clients are : "+arryL.size());
	}
	String send_ip_socket,all_ip_socket;
	
	public void run()
	{
		try
		{
			Scanner sc=new Scanner(s.getInputStream());
			
			String Line="";
			//do
			while(true)
			{
				if((sc.hasNextLine()))
				{
					send_ip_socket=sc.nextLine();
					Line=sc.nextLine();
					System.out.println(Cl_name+ " :"+Line);
					
					for(Socket sock : arryL)
						{
							
							all_ip_socket=sock.getRemoteSocketAddress()+"";
							if(!(all_ip_socket.equals(send_ip_socket)))
							{
					
								PrintWriter pw=new PrintWriter(sock.getOutputStream(),true);
								pw.println(Cl_name + " : " + Line);
								
							}
							else
							{
								if(Line.equals("bye"))
								{
									arryL.remove(sock);
									System.out.println(Cl_name + "  is Remove ...now Total Clients are.." + arryL.size());
									
							
								}
							}
						}
					
				}
				
			}//while(!Line.equals("bye"));
		  }
		  catch(Exception e)
		  {
		
		  }
	}
}

/************************************************ OUTPUT **************************************************


Z:\Assignment\q7>javac SeverApp.java

Z:\Assignment\q7>java SeverApp
Available clients are : 1
client 1 :Hello Brother
Available clients are : 2
client 2 :hello Brothers
Available clients are : 3
client 3 :hello i am Vimal
client 2 :Ok I am Gautam
Available clients are : 4
client 4 :hii I am John
client 3 :ok john welcome
client 4 :i am from japan


***********************************************************************************************************/