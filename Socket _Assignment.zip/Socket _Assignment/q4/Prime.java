import java.util.*;
import java.io.*;
class Prime
{

	public static void main(String[] arg)
	{
	
		int i=2,f=0;
		int str;
		System.out.println("enter no");
		Scanner sc = new Scanner(System.in);
		str=sc.nextInt();
		
		while( i <= (str / 2 ) )
		
		{
			if((str % i)==0)
			{
				f=1;
			}
			i=i+1;
		}
		if(f==1)
		{
			System.out.println("Not Prime");
		}
		else
		{
			System.out.println("Prime");
		}
	}
}