/*=======================================================================================================
ROLL NO		:	44	

NAME		:	VIMALKUMAR V VASAVA

COURCE/SEM	:	MCA - IV

SUBJECT		: DISTRIBUTED APPLICATION DEVELOPMENT

ASSIGNMENT	: 1
				4.	Create client and server socket programs to enable communication so that 
				client can get results of the following operations performed by the server.
					a)	Average of two numbers
					b)	Maximum of three numbers
					c)	Generate nth prime number
					d)	Generate nth Fibonacci number
		
========================================================================================================*/

import java.util.*;
import java.io.*;
import java.net.*;

class A_Server
{
	
	public static void main(String[] arg)
	{
		try
		{
			int sendData,receiveData,sum,avg,num1,num2,num3;
			int f_array[]=new int[30];
			ServerSocket ss=new ServerSocket(5050);
			System.out.println("Waiting for client");
			Socket s=ss.accept();
			System.out.println("Connection establish");
			while(true)
			{
				
				
				InputStream is=s.getInputStream();
				OutputStream os=s.getOutputStream();
				
				Scanner sc=new Scanner(is);
				PrintWriter pw = new PrintWriter(os,true);
				
				Scanner sendInput=new Scanner(System.in);
				
				
					//pw.println(" 1. Average of number \n 2. Larger number \n 3. Prime number \n 4. Fabbonici series \n 5. Exit");
					
					if(sc.hasNextLine())
					{
						receiveData=sc.nextInt();
						System.out.println(receiveData);
						switch(receiveData)
						{
							case 1:
									
									System.out.println("it is for average for three number");
									
									pw.println(receiveData+"\n"+"Enter Number 1");
									
									num1=sc.nextInt();
									
									pw.println("Enter Number 2");
									num2=sc.nextInt();
									
									pw.println("Enter Number 3");
									num3=sc.nextInt();
									
									sum=(num1+num2+num3);
									avg=(sum/3);
									pw.println("Sum of three Numbers: "+sum+"  Average of Three numbers: "+avg);
									
							break;
							
							case 2:
									System.out.println("it is for maximum");
									pw.println(receiveData);
									pw.println("Enter Number 1");
									num1=sc.nextInt();
									
									pw.println("Enter Number 2");
									num2=sc.nextInt();
									
									pw.println("Enter Number 3");
									num3=sc.nextInt();
									
									if(num1 > num2 && num1 > num3)
									{
										pw.println("Number : "+ num1 + " is larger than "+num2+ " and "+ num3);
										
									}
									if(num2 > num1 && num2 > num3)
									{
										pw.println("Number : "+ num2 + " is larger than "+num1+ " and "+ num3);
										
									}
									else
									{
										pw.println("Number : "+ num3 + " is larger than "+num1+ " and "+ num2);
										
									}
							break;
							
							case 3:
									int i=2,f=0;
									System.out.println("it is for Prime number");
									pw.println(receiveData);
									pw.println("Enter any number to check prime or not");
									num1=sc.nextInt();
									
									while( i <= (num1 / 2 ) )

										{
											if((num1 % i)==0)
											{
												f=1;
											}
											i=i+1;
										}
										if(f==1)
										{
											pw.println(num1 + " is not Prime Number");
										}
										else
										{
											pw.println(num1 + " is Prime Number");
										}
							
									
							break;
							
							case 4:
									System.out.println("it is for Fabbonici series");
									pw.println(receiveData);
									pw.println("Enter Number for fabbonici series ");
									num1=sc.nextInt();
									
									
									int a=0,b=1,c;
									String temp="";
									
									
									for(int j=0;j<num1;j++)
										{
											
											System.out.println(a);
											temp=temp+" "+a;
											c=a+b;
											a=b;
											b=c;
										}
										pw.println(temp);
									
									
									
								
							break;
							
							
						}
						
					}
			   
				
			}
			
	
			
		}
		catch(Exception e)
		{
		
		}
		
	}

}

/************************************************ OUTPUT **************************************************
Z:\Assignment\q4>javac A_Server.java

Z:\Assignment\q4>java A_Server
Waiting for client
Connection establish
1
it is for average for three number
2
it is for maximum
3
it is for Prime number
4
it is for Fabbonici series
**********************************************************************************************************/