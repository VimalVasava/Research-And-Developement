import java.util.*;
import java.io.*;
class Fabonacci
{

	static int a=0,b=1,c,value;
	public static void main(String[] arg)
	{
		Scanner sc=new Scanner(System.in);
		value=sc.nextInt();
		
		for(int i=0;i<value;i++)
		{
			System.out.println(a);
			c=a+b;
			a=b;
			b=c;
		}
		
		
	}
}